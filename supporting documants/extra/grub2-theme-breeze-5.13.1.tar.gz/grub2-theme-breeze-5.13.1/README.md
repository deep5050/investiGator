# Breeze
A minimalistic GRUB theme inspired by Breeze.

![Preview 1](preview01.png)
![Preview 2](preview02.png)
![Preview 3](preview03.png)
> Keep in mind that the previous screenshots were taken on a low-resolution QEMU virtual machine.

![Shipped icons and logos](icons.png)

## Installation
Copy the "breeze" folder to the themes directory in /boot. If you don't know how to do it, just run the included "install.sh" script as root.
